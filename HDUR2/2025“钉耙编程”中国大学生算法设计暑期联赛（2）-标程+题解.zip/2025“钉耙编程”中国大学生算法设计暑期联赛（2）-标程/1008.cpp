#include<bits/stdc++.h>
#define ll long long
#define pb push_back
using namespace std;

int main()
{
    int T=1;
    scanf("%d",&T);
    while(T--)
{
    ll n;
    scanf("%lld",&n);
    printf("%.4lf\n",n*3.0/2.0);
}
    return 0;
}
